@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'defineProjectionView AS Header'
@Metadata.ignorePropagatedAnnotations: true
@UI.headerInfo: { typeName: 'Count Document',
                  typeNamePlural: 'Count Documents',
                  title: { value: 'id' } }
define root view entity ZBUILD_HEADER_STORE as projection on ZDDHEADER_STORE 
{ 
 @UI.facet: [{ type: #FIELDGROUP_REFERENCE, targetQualifier: 'Main',
                label: 'General Information', position: 10 }]

@UI: { lineItem: [{ position: 10 }], fieldGroup: [{ qualifier: 'Main', position: 10 }] }
key id,
  @UI: { lineItem: [{ position: 20 }], fieldGroup: [{ qualifier: 'Main', position: 20 }],
         selectionField: [{ position: 10 }] }
storekey,
  @UI: { lineItem: [{ position: 30 }], fieldGroup: [{ qualifier: 'Main', position: 30 }],
         selectionField: [{ position: 20 }] }
status,
 @UI: { lineItem: [{ position: 40 }], fieldGroup: [{ qualifier: 'Main', position: 40 }] }
count_date,

  @UI: { lineItem: [{ position: 50 }], fieldGroup: [{ qualifier: 'Main', position: 50 }] }
createdby,
 @UI: { lineItem: [{ position: 60 }], fieldGroup: [{ qualifier: 'Main', position: 60 }] }
createdat
    
}
