@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Count Item - Projection'
@Metadata.ignorePropagatedAnnotations: true
@Metadata.allowExtensions: true
define view entity ZBUILD_ITEM_STORE
  as projection on ZDDITEM_STORE
{
  key id,
  key item_no,
      article,
      @Semantics.quantity.unitOfMeasure: 'unit'
      book_qty,
      @Semantics.quantity.unitOfMeasure: 'unit'
      counted_qty,
      unit,
      @Semantics.quantity.unitOfMeasure: 'unit'
      difference,
      is_counted,
      DiffCriticality,
      /* Associations */
      _Header : redirected to parent ZBUILD_HEADER_STORE
}
