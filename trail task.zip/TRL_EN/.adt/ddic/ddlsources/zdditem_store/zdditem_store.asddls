@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Count Item'
define view entity ZDDITEM_STORE
  as select from zitem_store
  association to parent ZDDHEADER_STORE as _Header
    on $projection.id = _Header.id
{
  key id,
  key item_no,
      article,
      @Semantics.quantity.unitOfMeasure: 'unit'
      book_qty,
      @Semantics.quantity.unitOfMeasure: 'unit'
      counted_qty,
      unit,
      @Semantics.quantity.unitOfMeasure: 'unit'
      difference,
      is_counted,
      case
        when difference < 0 then 1
        when difference > 0 then 2
        else 3
      end as DiffCriticality,
      _Header
}
