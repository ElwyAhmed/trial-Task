@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Count Header'
define root view entity ZDDHEADER_STORE
  as select from zheader_store
  composition [0..*] of ZDDITEM_STORE as _Item
{
  key id,
      storekey,
      status,
      count_date,
      createdby,
      createdat,
      _Item
}
